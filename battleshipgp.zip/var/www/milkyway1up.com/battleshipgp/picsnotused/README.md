# Battleship

A simple 2-player battleship game written in HTML and JavaScript to be played on the same computer

<img src="https://raw.githubusercontent.com/yberg/battleship/master/scrnshot.png" width="550"/>
